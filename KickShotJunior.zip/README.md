KickShotLevelOne
================

HTML5 Version of KickShot Level One
