pandaConfig = {
    name: 'KickShot Junior',
    version: '1.0.0',

    system: {
        width: 640,
        height: 960,
        rotateScreen: false
    },
    storage: {
        id: 'com.redcarddev.kickshotjunior'
    }
};
